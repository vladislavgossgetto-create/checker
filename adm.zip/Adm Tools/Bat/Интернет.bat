@echo off
start ms-settings:datausage