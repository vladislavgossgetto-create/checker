UnStone SMP — Resource Pack HD

Minecraft Java / Paper 1.21.11
pack_format: 75

Изменение в HD-версии:
- Логотип приветствия заменён исходным PNG 1024×213 вместо уменьшенной версии 128×27.
- Параметры bitmap-шрифта сохранены (height 27, ascent 22), поэтому логотип не должен стать крупнее.
- Все 31 значок рангов и шрифт fuxmine:ranks сохранены без изменений.

Установите ZIP целиком в папку resourcepacks или опубликуйте его по HTTPS для server.properties.
