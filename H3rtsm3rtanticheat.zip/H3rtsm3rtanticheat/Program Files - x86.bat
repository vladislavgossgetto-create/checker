@echo off
start "" "%ProgramFiles%"
start "" "%ProgramFiles(x86)%"