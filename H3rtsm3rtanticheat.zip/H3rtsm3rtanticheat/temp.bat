@echo off
start %TEMP%