@echo off
@color 1a
@start %windir%\Prefetch
@start %appdata%\Microsoft\Windows\Recent
@start %userprofile%\appdata\Local\Microsoft\Windows\History
