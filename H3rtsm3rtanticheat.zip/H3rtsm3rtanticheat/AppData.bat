@echo off
start "" "%USERPROFILE%\AppData"